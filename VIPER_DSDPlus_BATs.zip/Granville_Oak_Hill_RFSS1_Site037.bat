:: NC VIPER - Granville County - Oak Hill
:: RFSS 1 | Site 037 (0x25) | Ctrl: 853.2125 MHz
:: All site freqs: 851.250 851.750 852.200 852.550 852.950 853.2125 853.6375
FMPA -rc -o20001 -f853.2125
