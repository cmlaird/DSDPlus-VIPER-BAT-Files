:: NC VIPER - Hyde County - Rose Bay
:: RFSS 3 | Site 055 (0x37) | Ctrl: 852.4625 MHz
:: All site freqs: 851.4125 851.950 852.4625 853.8875 856.6125
FMPA -rc -o20001 -f852.4625
