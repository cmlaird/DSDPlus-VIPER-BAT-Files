:: NC VIPER - Montgomery County - Buck Mountain
:: RFSS 4 | Site 007 (0x7) | Ctrl: 774.31875 MHz
:: All site freqs: 769.35625 770.18125 771.28125 771.88125 772.30625 774.31875 774.59375
FMPA -rc -o20001 -f774.31875
