:: NC VIPER - Person County - Roxboro
:: RFSS 1 | Site 046 (0x2E) | Ctrl: 853.2875 MHz
:: All site freqs: 851.00625 852.8625 853.2875 853.675 854.2375 856.2625
FMPA -rc -o20001 -f853.2875
