:: NC VIPER - Northampton County - Eniva
:: RFSS 3 | Site 022 (0x16) | Ctrl: 852.475 MHz
:: All site freqs: 851.600 851.9125 852.275 852.475 853.675
FMPA -rc -o20001 -f852.475
