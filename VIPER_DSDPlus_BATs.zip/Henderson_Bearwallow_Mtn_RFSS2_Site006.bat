:: NC VIPER - Henderson County - Bearwallow Mtn
:: RFSS 2 | Site 006 (0x6) | Ctrl: 772.96875 MHz
:: All site freqs: 769.35625 771.30625 771.80625 772.38125 772.68125 772.96875 773.71875
FMPA -rc -o20001 -f772.96875
