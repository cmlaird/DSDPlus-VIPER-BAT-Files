:: NC VIPER - Person County - Hyco Lake
:: RFSS 1 | Site 071 (0x47) | Ctrl: 774.44375 MHz
:: All site freqs: 770.09375 771.30625 772.18125 773.70625 774.44375 774.63125
FMPA -rc -o20001 -f774.44375
