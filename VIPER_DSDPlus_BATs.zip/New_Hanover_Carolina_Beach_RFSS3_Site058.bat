:: NC VIPER - New Hanover County - Carolina Beach
:: RFSS 3 | Site 058 (0x3A) | Ctrl: 853.8875 MHz
:: All site freqs: 851.275 851.8375 852.5375 852.825 853.100 853.8875 858.9375
FMPA -rc -o20001 -f853.8875
