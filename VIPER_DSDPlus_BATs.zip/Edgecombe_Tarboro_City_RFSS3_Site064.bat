:: NC VIPER - Edgecombe County - Tarboro City
:: RFSS 3 | Site 064 (0x40) | Ctrl: 852.3125 MHz
:: All site freqs: 851.950 852.3125 853.6875 854.0375 856.2375 858.2375 859.2375
FMPA -rc -o20001 -f852.3125
