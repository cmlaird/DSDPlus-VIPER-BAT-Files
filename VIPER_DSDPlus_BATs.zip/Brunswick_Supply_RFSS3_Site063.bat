:: NC VIPER - Brunswick County - Supply
:: RFSS 3 | Site 063 (0x3F) | Ctrl: 853.0875 MHz
:: All site freqs: 851.1625 851.5875 851.7375 852.0875 852.5875 853.0875 853.6125
FMPA -rc -o20001 -f853.0875
