:: NC VIPER - Union County - Wingate
:: RFSS 4 | Site 045 (0x2D) | Ctrl: 852.300 MHz
:: All site freqs: 851.250 851.550 851.925 852.300 853.5625
FMPA -rc -o20001 -f852.300
