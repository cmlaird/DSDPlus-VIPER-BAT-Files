:: NC VIPER - Alamance County - Altamahaw
:: RFSS 1 | Site 001 (0x1) | Ctrl: 856.0125 MHz
:: All site freqs: 852.1375 852.5875 852.6125 852.8875 853.6375 853.8375 856.0125 858.5875
FMPA -rc -o20001 -f856.0125
