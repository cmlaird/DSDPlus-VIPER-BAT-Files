:: NC VIPER - Dare County - East Lake
:: RFSS 3 | Site 018 (0x12) | Ctrl: 852.725 MHz
:: All site freqs: 851.1625 851.575 852.0875 852.725 853.625
FMPA -rc -o20001 -f852.725
