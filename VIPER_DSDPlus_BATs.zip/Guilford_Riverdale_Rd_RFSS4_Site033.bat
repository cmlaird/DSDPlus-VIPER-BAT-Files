:: NC VIPER - Guilford County - Riverdale Rd
:: RFSS 4 | Site 033 (0x21) | Ctrl: 853.875 MHz
:: All site freqs: 851.075 851.9875 852.4125 852.975 853.2375 853.875 854.0625 856.1375
FMPA -rc -o20001 -f853.875
