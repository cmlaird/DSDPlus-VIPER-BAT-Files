:: NC VIPER - Madison County - Hap Mtn
:: RFSS 2 | Site 098 (0x62) | Ctrl: 773.68125 MHz
:: All site freqs: 771.18125 771.50625 771.95625 773.68125 774.88125
FMPA -rc -o20001 -f773.68125
