:: NC VIPER - Macon County - Wine Springs
:: RFSS 2 | Site 089 (0x59) | Ctrl: 853.1125 MHz
:: All site freqs: 851.1375 851.3875 851.925 852.3375 853.1125 853.875 855.7375
FMPA -rc -o20001 -f853.1125
