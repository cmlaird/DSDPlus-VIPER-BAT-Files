:: NC VIPER - Granville County - Oxford WT
:: RFSS 1 | Site 039 (0x27) | Ctrl: 852.975 MHz
:: All site freqs: 851.300 851.7375 852.300 852.600 852.975 853.1625 853.950
FMPA -rc -o20001 -f852.975
