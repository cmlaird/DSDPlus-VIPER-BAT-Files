:: NC VIPER - Surry County - Chestnut Ridge
:: RFSS 4 | Site 008 (0x8) | Ctrl: 853.050 MHz
:: All site freqs: 851.275 851.775 852.3625 853.050 853.975 857.0625 857.9875
FMPA -rc -o20001 -f853.050
