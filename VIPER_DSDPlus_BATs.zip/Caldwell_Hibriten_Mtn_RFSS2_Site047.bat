:: NC VIPER - Caldwell County - Hibriten Mtn
:: RFSS 2 | Site 047 (0x2F) | Ctrl: 856.8125 MHz
:: All site freqs: 851.175 851.775 852.075 852.900 853.325 854.6375 856.0125 856.8125 857.5875
FMPA -rc -o20001 -f856.8125
