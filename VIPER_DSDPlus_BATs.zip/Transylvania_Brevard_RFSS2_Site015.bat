:: NC VIPER - Transylvania County - Brevard
:: RFSS 2 | Site 015 (0xF) | Ctrl: 853.175 MHz
:: All site freqs: 851.050 851.6125 852.6125 853.175 853.8375
FMPA -rc -o20001 -f853.175
