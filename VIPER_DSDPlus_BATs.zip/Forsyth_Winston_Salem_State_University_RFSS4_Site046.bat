:: NC VIPER - Forsyth County - Winston Salem State University
:: RFSS 4 | Site 046 (0x2E) | Ctrl: 855.9875 MHz
:: All site freqs: 852.2125 852.550 852.9875 853.4875 853.950 855.9875 856.7375
FMPA -rc -o20001 -f855.9875
