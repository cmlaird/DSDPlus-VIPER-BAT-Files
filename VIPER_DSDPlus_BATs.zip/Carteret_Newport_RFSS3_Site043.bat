:: NC VIPER - Carteret County - Newport
:: RFSS 3 | Site 043 (0x2B) | Ctrl: 852.8375 MHz
:: All site freqs: 851.0875 851.3375 851.8375 852.3375 852.8375 853.3375 858.4375 858.7625
FMPA -rc -o20001 -f852.8375
