:: NC VIPER - Alleghany County - Green Mtn
:: RFSS 4 | Site 020 (0x14) | Ctrl: 852.975 MHz
:: All site freqs: 851.3875 851.8875 852.5625 852.975 853.5875 855.7875
FMPA -rc -o20001 -f852.975
