:: NC VIPER - Franklin County - Youngsville
:: RFSS 1 | Site 066 (0x42) | Ctrl: 774.58125 MHz
:: All site freqs: 769.15625 769.93125 770.18125 772.53125 772.98125 774.58125 774.83125
FMPA -rc -o20001 -f774.58125
