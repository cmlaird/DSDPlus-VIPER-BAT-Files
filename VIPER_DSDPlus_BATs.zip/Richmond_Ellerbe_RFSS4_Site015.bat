:: NC VIPER - Richmond County - Ellerbe
:: RFSS 4 | Site 015 (0xF) | Ctrl: 852.575 MHz
:: All site freqs: 851.375 851.7125 852.075 852.575 853.6875 857.9375 858.4375
FMPA -rc -o20001 -f852.575
