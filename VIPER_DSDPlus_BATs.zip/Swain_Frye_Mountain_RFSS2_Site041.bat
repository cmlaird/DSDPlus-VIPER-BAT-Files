:: NC VIPER - Swain County - Frye Mountain
:: RFSS 2 | Site 041 (0x29) | Ctrl: 853.3875 MHz
:: All site freqs: 851.350 851.6625 852.175 852.850 853.3875 853.9875 856.7375
FMPA -rc -o20001 -f853.3875
