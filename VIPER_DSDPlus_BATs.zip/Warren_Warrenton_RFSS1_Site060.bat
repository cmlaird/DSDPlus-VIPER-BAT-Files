:: NC VIPER - Warren County - Warrenton
:: RFSS 1 | Site 060 (0x3C) | Ctrl: 852.8375 MHz
:: All site freqs: 851.2125 851.6625 851.9375 852.8375 853.0875 853.400
FMPA -rc -o20001 -f852.8375
