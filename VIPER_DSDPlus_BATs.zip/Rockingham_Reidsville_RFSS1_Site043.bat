:: NC VIPER - Rockingham County - Reidsville
:: RFSS 1 | Site 043 (0x2B) | Ctrl: 853.575 MHz
:: All site freqs: 851.050 851.4125 851.625 851.900 852.8125 853.1875 853.575 853.7875
FMPA -rc -o20001 -f853.575
