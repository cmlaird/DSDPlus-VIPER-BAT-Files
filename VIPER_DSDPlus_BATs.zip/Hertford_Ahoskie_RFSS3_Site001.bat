:: NC VIPER - Hertford County - Ahoskie
:: RFSS 3 | Site 001 (0x1) | Ctrl: 852.425 MHz
:: All site freqs: 851.150 851.675 851.975 852.425 853.5625 853.7125
FMPA -rc -o20001 -f852.425
