:: NC VIPER - Moore County - Carthage
:: RFSS 1 | Site 011 (0xB) | Ctrl: 853.675 MHz
:: All site freqs: 851.275 851.600 851.975 852.550 852.950 853.1125 853.325 853.675 855.5375
FMPA -rc -o20001 -f853.675
