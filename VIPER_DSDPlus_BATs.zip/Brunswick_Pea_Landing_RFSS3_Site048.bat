:: NC VIPER - Brunswick County - Pea Landing
:: RFSS 3 | Site 048 (0x30) | Ctrl: 852.7125 MHz
:: All site freqs: 851.0375 851.550 851.850 852.150 852.3875 852.7125 853.675
FMPA -rc -o20001 -f852.7125
