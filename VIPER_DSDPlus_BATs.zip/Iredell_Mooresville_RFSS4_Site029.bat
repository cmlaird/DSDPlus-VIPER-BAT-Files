:: NC VIPER - Iredell County - Mooresville
:: RFSS 4 | Site 029 (0x1D) | Ctrl: 852.950 MHz
:: All site freqs: 851.200 851.850 852.1625 852.400 852.950 853.8875 854.2875 854.5875
FMPA -rc -o20001 -f852.950
