:: NC VIPER - Haywood County - Chambers Mtn
:: RFSS 2 | Site 020 (0x14) | Ctrl: 854.4375 MHz
:: All site freqs: 851.2125 851.725 851.9875 852.575 853.7875 854.4375 856.1125
FMPA -rc -o20001 -f854.4375
