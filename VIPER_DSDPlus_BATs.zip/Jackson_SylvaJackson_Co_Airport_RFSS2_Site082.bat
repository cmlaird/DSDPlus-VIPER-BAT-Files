:: NC VIPER - Jackson County - Sylva/Jackson Co Airport
:: RFSS 2 | Site 082 (0x52) | Ctrl: 853.150 MHz
:: All site freqs: 851.300 852.3875 852.6375 853.150 853.8875
FMPA -rc -o20001 -f853.150
