:: NC VIPER - Dare County - Buxton
:: RFSS 3 | Site 010 (0xA) | Ctrl: 852.3125 MHz
:: All site freqs: 851.050 851.400 851.800 852.3125 853.3375
FMPA -rc -o20001 -f852.3125
