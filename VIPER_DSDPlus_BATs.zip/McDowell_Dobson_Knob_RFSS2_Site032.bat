:: NC VIPER - McDowell County - Dobson Knob
:: RFSS 2 | Site 032 (0x20) | Ctrl: 859.0125 MHz
:: All site freqs: 851.950 852.275 852.675 853.250 853.8625 855.2875 859.0125 859.8125
FMPA -rc -o20001 -f859.0125
