:: NC VIPER - Ashe County - Deep Gap Mtn
:: RFSS 2 | Site 031 (0x1F) | Ctrl: 853.9125 MHz
:: All site freqs: 851.325 852.050 852.9375 853.9125 855.2125
FMPA -rc -o20001 -f853.9125
