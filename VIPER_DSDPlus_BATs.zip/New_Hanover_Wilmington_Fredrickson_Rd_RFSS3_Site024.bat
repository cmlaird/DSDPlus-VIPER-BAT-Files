:: NC VIPER - New Hanover County - Wilmington Fredrickson Rd
:: RFSS 3 | Site 024 (0x18) | Ctrl: 853.125 MHz
:: All site freqs: 851.125 851.375 851.6375 852.0625 852.325 852.8125 853.125 853.5875
FMPA -rc -o20001 -f853.125
