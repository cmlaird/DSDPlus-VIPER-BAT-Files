:: NC VIPER - Sampson County - Salemburg
:: RFSS 3 | Site 056 (0x38) | Ctrl: 852.775 MHz
:: All site freqs: 851.550 851.8625 852.4375 852.775 853.875
FMPA -rc -o20001 -f852.775
