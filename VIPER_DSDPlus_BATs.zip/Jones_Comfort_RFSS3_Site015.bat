:: NC VIPER - Jones County - Comfort
:: RFSS 3 | Site 015 (0xF) | Ctrl: 852.375 MHz
:: All site freqs: 851.0625 851.5625 852.0875 852.375 853.3625
FMPA -rc -o20001 -f852.375
