:: NC VIPER - Hyde County - Ponzor
:: RFSS 3 | Site 051 (0x33) | Ctrl: 852.325 MHz
:: All site freqs: 851.175 851.6375 851.9375 852.325 853.825
FMPA -rc -o20001 -f852.325
