:: NC VIPER - Gates County - Gatesville DOC
:: RFSS 3 | Site 026 (0x1A) | Ctrl: 852.400 MHz
:: All site freqs: 851.1875 851.550 852.100 852.400 853.450
FMPA -rc -o20001 -f852.400
