:: NC VIPER - Cumberland County - Cedar Creek
:: RFSS 3 | Site 011 (0xB) | Ctrl: 853.8875 MHz
:: All site freqs: 851.100 851.3625 851.8875 852.100 852.625 852.900 853.100 853.3625 853.575 853.8875
FMPA -rc -o20001 -f853.8875
