:: NC VIPER - Harnett County - Erwin PE
:: RFSS 1 | Site 020 (0x14) | Ctrl: 853.4375 MHz
:: All site freqs: 851.4125 852.175 852.3875 852.8875 853.0875 853.275 853.4375 853.9875
FMPA -rc -o20001 -f853.4375
