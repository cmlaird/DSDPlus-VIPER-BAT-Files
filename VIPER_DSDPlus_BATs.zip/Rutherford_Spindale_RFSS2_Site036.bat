:: NC VIPER - Rutherford County - Spindale
:: RFSS 2 | Site 036 (0x24) | Ctrl: 852.700 MHz
:: All site freqs: 851.3375 851.925 852.3875 852.700 853.850 854.0375 856.2125 858.1125
FMPA -rc -o20001 -f852.700
