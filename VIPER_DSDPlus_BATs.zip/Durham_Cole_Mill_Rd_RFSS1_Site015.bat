:: NC VIPER - Durham County - Cole Mill Rd
:: RFSS 1 | Site 015 (0xF) | Ctrl: 857.0875 MHz
:: All site freqs: 851.275 851.9875 852.275 852.775 853.450 853.775 857.0875 859.5125
FMPA -rc -o20001 -f857.0875
