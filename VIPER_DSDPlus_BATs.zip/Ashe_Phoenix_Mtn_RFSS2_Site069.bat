:: NC VIPER - Ashe County - Phoenix Mtn
:: RFSS 2 | Site 069 (0x45) | Ctrl: 852.4375 MHz
:: All site freqs: 851.1125 851.7875 852.125 852.4375 853.8875
FMPA -rc -o20001 -f852.4375
