:: NC VIPER - Harnett County - Lillington
:: RFSS 1 | Site 028 (0x1C) | Ctrl: 853.3375 MHz
:: All site freqs: 851.0875 851.3375 851.5625 852.0625 852.475 852.8375 853.3375 854.9875
FMPA -rc -o20001 -f853.3375
