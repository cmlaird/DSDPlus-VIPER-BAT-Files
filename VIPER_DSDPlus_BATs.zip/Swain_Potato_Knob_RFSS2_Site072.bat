:: NC VIPER - Swain County - Potato Knob
:: RFSS 2 | Site 072 (0x48) | Ctrl: 853.225 MHz
:: All site freqs: 851.475 852.425 852.775 853.225 853.475
FMPA -rc -o20001 -f853.225
