:: NC VIPER - Halifax County - Halifax
:: RFSS 3 | Site 029 (0x1D) | Ctrl: 852.3375 MHz
:: All site freqs: 851.0875 851.4125 851.800 852.3375 853.625
FMPA -rc -o20001 -f852.3375
