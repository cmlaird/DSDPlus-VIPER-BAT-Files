:: NC VIPER - Yancey County - Clingmans Pk
:: RFSS 2 | Site 026 (0x1A) | Ctrl: 855.7375 MHz
:: All site freqs: 851.350 851.625 851.900 852.950 853.6125 855.7375 856.7875
FMPA -rc -o20001 -f855.7375
