:: NC VIPER - Orange County - Laws
:: RFSS 1 | Site 026 (0x1A) | Ctrl: 858.5375 MHz
:: All site freqs: 851.1125 851.475 852.050 852.5625 853.850 857.6625 858.5375 859.7625
FMPA -rc -o20001 -f858.5375
