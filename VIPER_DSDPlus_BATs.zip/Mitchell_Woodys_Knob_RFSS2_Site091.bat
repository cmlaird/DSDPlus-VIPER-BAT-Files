:: NC VIPER - Mitchell County - Woodys Knob
:: RFSS 2 | Site 091 (0x5B) | Ctrl: 774.13125 MHz
:: All site freqs: 770.79375 771.19375 771.64375 771.96875 772.25625 774.13125 774.38125
FMPA -rc -o20001 -f774.13125
