:: NC VIPER - Hoke County - McCain Hospital
:: RFSS 1 | Site 033 (0x21) | Ctrl: 858.2375 MHz
:: All site freqs: 851.1125 851.400 851.9125 852.3125 853.850 857.2375 858.2375 859.2375
FMPA -rc -o20001 -f858.2375
