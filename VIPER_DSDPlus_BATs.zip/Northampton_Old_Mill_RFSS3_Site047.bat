:: NC VIPER - Northampton County - Old Mill
:: RFSS 3 | Site 047 (0x2F) | Ctrl: 852.8875 MHz
:: All site freqs: 851.4375 851.750 852.575 852.8875 853.8875
FMPA -rc -o20001 -f852.8875
