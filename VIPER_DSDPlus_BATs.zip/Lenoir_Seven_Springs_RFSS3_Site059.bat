:: NC VIPER - Lenoir County - Seven Springs
:: RFSS 3 | Site 059 (0x3B) | Ctrl: 853.6625 MHz
:: All site freqs: 851.450 851.9125 853.1875 853.6625 853.9125
FMPA -rc -o20001 -f853.6625
