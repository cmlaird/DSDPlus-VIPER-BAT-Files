:: NC VIPER - Cleveland County - Boiling Springs
:: RFSS 2 | Site 013 (0xD) | Ctrl: 773.15625 MHz
:: All site freqs: 771.85625 772.30625 772.65625 773.15625 773.41875
FMPA -rc -o20001 -f773.15625
