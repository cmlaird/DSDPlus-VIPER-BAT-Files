:: NC VIPER - Catawba County - Riverbend Rd
:: RFSS 2 | Site 075 (0x4B) | Ctrl: 852.200 MHz
:: All site freqs: 851.1375 851.400 851.750 852.200 853.625 854.2625 856.1375 858.1375
FMPA -rc -o20001 -f852.200
