:: NC VIPER - Watauga County - Buckeye Knob
:: RFSS 2 | Site 018 (0x12) | Ctrl: 852.6875 MHz
:: All site freqs: 851.200 851.5625 852.100 852.6875 853.975
FMPA -rc -o20001 -f852.6875
