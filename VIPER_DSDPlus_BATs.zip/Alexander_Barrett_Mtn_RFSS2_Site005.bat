:: NC VIPER - Alexander County - Barrett Mtn
:: RFSS 2 | Site 005 (0x5) | Ctrl: 858.0375 MHz
:: All site freqs: 851.2875 852.300 852.575 853.050 853.6625 856.0375 857.0375 858.0375 859.1375
FMPA -rc -o20001 -f858.0375
