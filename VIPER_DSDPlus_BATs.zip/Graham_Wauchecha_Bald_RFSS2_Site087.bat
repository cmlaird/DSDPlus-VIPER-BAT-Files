:: NC VIPER - Graham County - Wauchecha Bald
:: RFSS 2 | Site 087 (0x57) | Ctrl: 853.6875 MHz
:: All site freqs: 851.5375 852.375 852.700 853.6875 853.9875
FMPA -rc -o20001 -f853.6875
