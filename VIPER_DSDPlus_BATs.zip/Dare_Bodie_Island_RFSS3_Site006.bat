:: NC VIPER - Dare County - Bodie Island
:: RFSS 3 | Site 006 (0x6) | Ctrl: 852.5875 MHz
:: All site freqs: 851.450 851.975 852.400 852.5875 853.5875
FMPA -rc -o20001 -f852.5875
