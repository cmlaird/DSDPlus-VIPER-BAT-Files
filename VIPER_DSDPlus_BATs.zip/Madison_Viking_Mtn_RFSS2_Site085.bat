:: NC VIPER - Madison County - Viking Mtn
:: RFSS 2 | Site 085 (0x55) | Ctrl: 852.200 MHz
:: All site freqs: 851.0875 851.4125 851.800 852.200 853.3375
FMPA -rc -o20001 -f852.200
