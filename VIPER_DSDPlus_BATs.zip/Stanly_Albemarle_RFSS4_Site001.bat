:: NC VIPER - Stanly County - Albemarle
:: RFSS 4 | Site 001 (0x1) | Ctrl: 852.725 MHz
:: All site freqs: 851.1625 851.725 852.200 852.725 853.6375 856.6375
FMPA -rc -o20001 -f852.725
