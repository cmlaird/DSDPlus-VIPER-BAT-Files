:: NC VIPER - Robeson County - Proctorville
:: RFSS 3 | Site 052 (0x34) | Ctrl: 852.975 MHz
:: All site freqs: 851.375 851.7125 852.575 852.975 853.825
FMPA -rc -o20001 -f852.975
