:: NC VIPER - Wayne County - Lee Plant PE
:: RFSS 3 | Site 038 (0x26) | Ctrl: 853.1375 MHz
:: All site freqs: 851.6375 852.050 852.750 853.1375 853.5125 858.0625
FMPA -rc -o20001 -f853.1375
