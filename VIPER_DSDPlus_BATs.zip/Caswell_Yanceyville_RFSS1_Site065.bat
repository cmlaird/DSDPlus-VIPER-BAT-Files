:: NC VIPER - Caswell County - Yanceyville
:: RFSS 1 | Site 065 (0x41) | Ctrl: 852.800 MHz
:: All site freqs: 851.225 851.6875 852.375 852.800 853.975
FMPA -rc -o20001 -f852.800
