:: NC VIPER - Clay County - Chunky Gal Gap
:: RFSS 2 | Site 024 (0x18) | Ctrl: 853.0375 MHz
:: All site freqs: 853.0375 854.4625 855.9625 856.2625 858.4875
FMPA -rc -o20001 -f853.0375
