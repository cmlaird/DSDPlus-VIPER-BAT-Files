:: NC VIPER - Greene County - Farmville
:: RFSS 3 | Site 023 (0x17) | Ctrl: 853.100 MHz
:: All site freqs: 851.050 851.575 851.8375 852.100 852.600 853.100 853.6125
FMPA -rc -o20001 -f853.100
