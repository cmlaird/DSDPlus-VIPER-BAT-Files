:: NC VIPER - Columbus County - Delco
:: RFSS 3 | Site 016 (0x10) | Ctrl: 853.5125 MHz
:: All site freqs: 851.4625 851.750 852.2375 852.7375 853.250 853.5125 853.750
FMPA -rc -o20001 -f853.5125
