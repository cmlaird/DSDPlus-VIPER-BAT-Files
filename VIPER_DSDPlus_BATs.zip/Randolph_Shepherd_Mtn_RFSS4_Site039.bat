:: NC VIPER - Randolph County - Shepherd Mtn
:: RFSS 4 | Site 039 (0x27) | Ctrl: 858.0125 MHz
:: All site freqs: 851.100 851.825 852.475 853.1625 853.2875 853.700 853.825 857.8375 858.0125 858.7875
FMPA -rc -o20001 -f858.0125
