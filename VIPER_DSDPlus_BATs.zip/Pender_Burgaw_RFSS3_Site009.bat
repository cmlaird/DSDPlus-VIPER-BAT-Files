:: NC VIPER - Pender County - Burgaw
:: RFSS 3 | Site 009 (0x9) | Ctrl: 852.350 MHz
:: All site freqs: 851.100 851.425 851.825 852.350 853.2375
FMPA -rc -o20001 -f852.350
