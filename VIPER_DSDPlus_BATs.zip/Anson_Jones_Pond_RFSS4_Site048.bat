:: NC VIPER - Anson County - Jones Pond
:: RFSS 4 | Site 048 (0x30) | Ctrl: 773.71875 MHz
:: All site freqs: 770.28125 771.13125 771.95625 772.38125 773.71875 774.74375
FMPA -rc -o20001 -f773.71875
