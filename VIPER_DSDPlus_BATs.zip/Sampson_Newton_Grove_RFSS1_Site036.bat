:: NC VIPER - Sampson County - Newton Grove
:: RFSS 1 | Site 036 (0x24) | Ctrl: 853.625 MHz
:: All site freqs: 851.275 852.275 852.825 853.050 853.625 853.775
FMPA -rc -o20001 -f853.625
