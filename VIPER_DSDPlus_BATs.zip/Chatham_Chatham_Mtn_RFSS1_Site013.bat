:: NC VIPER - Chatham County - Chatham Mtn
:: RFSS 1 | Site 013 (0xD) | Ctrl: 853.4125 MHz
:: All site freqs: 851.2375 851.6625 852.2125 853.4125 853.6875 857.5375 858.1125 859.1125
FMPA -rc -o20001 -f853.4125
