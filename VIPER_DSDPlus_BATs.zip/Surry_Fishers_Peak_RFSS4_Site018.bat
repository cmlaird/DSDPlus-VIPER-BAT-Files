:: NC VIPER - Surry County - Fishers Peak
:: RFSS 4 | Site 018 (0x12) | Ctrl: 852.4125 MHz
:: All site freqs: 851.2375 851.8125 852.4125 853.8375 855.4875 856.2375 859.0375
FMPA -rc -o20001 -f852.4125
