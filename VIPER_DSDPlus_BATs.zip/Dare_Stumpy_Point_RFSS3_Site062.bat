:: NC VIPER - Dare County - Stumpy Point
:: RFSS 3 | Site 062 (0x3E) | Ctrl: 852.425 MHz
:: All site freqs: 851.2125 851.6125 852.1375 852.425 853.9125
FMPA -rc -o20001 -f852.425
