:: NC VIPER - Currituck County - Barco
:: RFSS 3 | Site 003 (0x3) | Ctrl: 852.275 MHz
:: All site freqs: 851.1375 851.4375 851.8375 852.275 853.3375
FMPA -rc -o20001 -f852.275
