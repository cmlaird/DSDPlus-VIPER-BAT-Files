:: NC VIPER - Vance County - Oxford Bi-Com
:: RFSS 1 | Site 038 (0x26) | Ctrl: 853.1875 MHz
:: All site freqs: 851.575 851.900 852.1875 852.575 852.925 853.1875 853.4875 853.8875
FMPA -rc -o20001 -f853.1875
