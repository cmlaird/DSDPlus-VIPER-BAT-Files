:: NC VIPER - Cleveland County - Benns Knob
:: RFSS 2 | Site 009 (0x9) | Ctrl: 857.4625 MHz
:: All site freqs: 853.1875 853.4125 853.825 856.4625 857.2125 857.4625 858.4625
FMPA -rc -o20001 -f857.4625
