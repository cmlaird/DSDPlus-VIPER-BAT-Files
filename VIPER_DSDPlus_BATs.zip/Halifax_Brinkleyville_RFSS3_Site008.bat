:: NC VIPER - Halifax County - Brinkleyville
:: RFSS 3 | Site 008 (0x8) | Ctrl: 853.700 MHz
:: All site freqs: 852.4375 853.3375 853.500 853.700 853.850
FMPA -rc -o20001 -f853.700
