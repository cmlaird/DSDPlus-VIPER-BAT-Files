:: NC VIPER - Watauga County - Boone
:: RFSS 2 | Site 014 (0xE) | Ctrl: 852.9625 MHz
:: All site freqs: 851.075 851.725 852.2875 852.9625 853.7625 854.3375 857.5125
FMPA -rc -o20001 -f852.9625
