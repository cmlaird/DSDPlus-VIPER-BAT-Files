:: NC VIPER - Granville County - Butner
:: RFSS 1 | Site 008 (0x8) | Ctrl: 853.6125 MHz
:: All site freqs: 851.925 852.225 852.3125 852.725 853.350 853.6125 853.8125
FMPA -rc -o20001 -f853.6125
