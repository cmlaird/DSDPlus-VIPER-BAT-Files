:: NC VIPER - Cherokee County - Joanna Bald
:: RFSS 2 | Site 052 (0x34) | Ctrl: 853.325 MHz
:: All site freqs: 851.825 852.075 852.825 853.175 853.325 853.7625 856.6375
FMPA -rc -o20001 -f853.325
