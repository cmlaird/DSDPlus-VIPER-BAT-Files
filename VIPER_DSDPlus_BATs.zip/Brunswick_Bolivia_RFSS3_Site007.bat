:: NC VIPER - Brunswick County - Bolivia
:: RFSS 3 | Site 007 (0x7) | Ctrl: 853.875 MHz
:: All site freqs: 851.0875 852.175 852.375 852.625 852.875 853.375 853.875 856.6875
FMPA -rc -o20001 -f853.875
