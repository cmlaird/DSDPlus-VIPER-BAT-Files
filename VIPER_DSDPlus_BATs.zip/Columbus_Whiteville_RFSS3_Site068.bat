:: NC VIPER - Columbus County - Whiteville
:: RFSS 3 | Site 068 (0x44) | Ctrl: 852.6875 MHz
:: All site freqs: 851.1125 851.475 851.9375 852.6875 853.625
FMPA -rc -o20001 -f852.6875
