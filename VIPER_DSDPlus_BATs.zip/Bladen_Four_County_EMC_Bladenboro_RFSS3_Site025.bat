:: NC VIPER - Bladen County - Four County EMC Bladenboro
:: RFSS 3 | Site 025 (0x19) | Ctrl: 852.8625 MHz
:: All site freqs: 851.1375 851.7875 852.425 852.8625 853.7875 854.5125 856.0375
FMPA -rc -o20001 -f852.8625
