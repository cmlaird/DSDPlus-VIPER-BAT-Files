:: NC VIPER - Halifax County - Scotland Neck
:: RFSS 3 | Site 075 (0x4B) | Ctrl: 773.65625 MHz
:: All site freqs: 771.04375 771.71875 772.30625 772.63125 773.40625 773.65625 774.43125
FMPA -rc -o20001 -f773.65625
