:: NC VIPER - Caldwell County - Butte Mtn
:: RFSS 2 | Site 019 (0x13) | Ctrl: 852.9875 MHz
:: All site freqs: 851.4125 851.9375 852.4125 852.9875 853.825 859.0875
FMPA -rc -o20001 -f852.9875
