:: NC VIPER - Yadkin County - Yadkin Rest Area I77
:: RFSS 4 | Site 024 (0x18) | Ctrl: 853.6875 MHz
:: All site freqs: 851.4875 851.8375 852.0625 852.7125 853.6875 853.800
FMPA -rc -o20001 -f853.6875
