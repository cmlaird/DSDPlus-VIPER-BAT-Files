:: NC VIPER - Anson County - McFarlan
:: RFSS 4 | Site 026 (0x1A) | Ctrl: 853.050 MHz
:: All site freqs: 851.050 851.4625 852.1375 853.050 853.5875
FMPA -rc -o20001 -f853.050
