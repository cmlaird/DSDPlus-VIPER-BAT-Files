:: NC VIPER - Granville County - Bullock WICE FM
:: RFSS 1 | Site 017 (0x11) | Ctrl: 853.250 MHz
:: All site freqs: 851.1375 851.4875 852.1625 852.6375 853.250 853.550 853.975
FMPA -rc -o20001 -f853.250
