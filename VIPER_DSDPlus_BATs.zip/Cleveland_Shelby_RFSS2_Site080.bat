:: NC VIPER - Cleveland County - Shelby
:: RFSS 2 | Site 080 (0x50) | Ctrl: 852.750 MHz
:: All site freqs: 851.300 851.800 852.300 852.750 853.9125
FMPA -rc -o20001 -f852.750
