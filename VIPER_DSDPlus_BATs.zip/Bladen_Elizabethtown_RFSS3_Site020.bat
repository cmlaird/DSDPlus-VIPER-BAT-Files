:: NC VIPER - Bladen County - Elizabethtown
:: RFSS 3 | Site 020 (0x14) | Ctrl: 852.400 MHz
:: All site freqs: 851.2375 851.6875 852.1125 852.400 853.5625 856.7375 857.4625 858.4625 859.4625
FMPA -rc -o20001 -f852.400
