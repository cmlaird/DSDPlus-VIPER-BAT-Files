:: NC VIPER - Stokes County - Booth Mtn
:: RFSS 4 | Site 006 (0x6) | Ctrl: 853.5125 MHz
:: All site freqs: 851.175 851.725 852.0875 852.450 853.5125 856.5875
FMPA -rc -o20001 -f853.5125
