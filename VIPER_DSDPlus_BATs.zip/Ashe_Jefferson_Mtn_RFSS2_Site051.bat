:: NC VIPER - Ashe County - Jefferson Mtn
:: RFSS 2 | Site 051 (0x33) | Ctrl: 853.2125 MHz
:: All site freqs: 851.675 851.9625 852.550 853.2125 859.7125
FMPA -rc -o20001 -f853.2125
