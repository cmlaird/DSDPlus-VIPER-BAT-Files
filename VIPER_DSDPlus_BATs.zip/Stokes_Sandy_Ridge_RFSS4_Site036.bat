:: NC VIPER - Stokes County - Sandy Ridge
:: RFSS 4 | Site 036 (0x24) | Ctrl: 853.750 MHz
:: All site freqs: 851.375 851.775 852.3125 852.725 853.750 859.7375
FMPA -rc -o20001 -f853.750
