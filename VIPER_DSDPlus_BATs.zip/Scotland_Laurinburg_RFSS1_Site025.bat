:: NC VIPER - Scotland County - Laurinburg
:: RFSS 1 | Site 025 (0x19) | Ctrl: 855.9875 MHz
:: All site freqs: 851.250 851.725 852.1625 852.825 853.100 853.450 855.9875 856.4625
FMPA -rc -o20001 -f855.9875
