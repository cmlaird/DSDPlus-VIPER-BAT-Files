:: NC VIPER - Jackson County - Toxaway Mtn
:: RFSS 2 | Site 066 (0x42) | Ctrl: 853.3375 MHz
:: All site freqs: 852.5375 852.875 853.3375 853.825 855.4625
FMPA -rc -o20001 -f853.3375
