:: NC VIPER - Stokes County - Sauratown Mtn
:: RFSS 4 | Site 037 (0x25) | Ctrl: 854.3625 MHz
:: All site freqs: 851.300 851.6125 852.300 852.9625 853.450 854.3625 855.7375
FMPA -rc -o20001 -f854.3625
