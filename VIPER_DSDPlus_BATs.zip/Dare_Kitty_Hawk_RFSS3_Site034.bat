:: NC VIPER - Dare County - Kitty Hawk
:: RFSS 3 | Site 034 (0x22) | Ctrl: 852.925 MHz
:: All site freqs: 851.5375 852.100 852.400 852.925 853.4375
FMPA -rc -o20001 -f852.925
