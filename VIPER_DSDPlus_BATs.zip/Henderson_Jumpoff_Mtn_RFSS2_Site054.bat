:: NC VIPER - Henderson County - Jumpoff Mtn
:: RFSS 2 | Site 054 (0x36) | Ctrl: 852.475 MHz
:: All site freqs: 851.100 851.3875 851.975 852.475 853.6875
FMPA -rc -o20001 -f852.475
