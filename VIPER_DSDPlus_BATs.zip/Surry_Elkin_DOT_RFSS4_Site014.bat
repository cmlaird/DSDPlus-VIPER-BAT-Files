:: NC VIPER - Surry County - Elkin DOT
:: RFSS 4 | Site 014 (0xE) | Ctrl: 853.225 MHz
:: All site freqs: 851.0625 851.950 852.800 853.225 858.6875 859.0125
FMPA -rc -o20001 -f853.225
