:: NC VIPER - Hyde County - Engelhard
:: RFSS 3 | Site 021 (0x15) | Ctrl: 853.975 MHz
:: All site freqs: 851.3375 851.7375 852.050 852.975 853.975
FMPA -rc -o20001 -f853.975
