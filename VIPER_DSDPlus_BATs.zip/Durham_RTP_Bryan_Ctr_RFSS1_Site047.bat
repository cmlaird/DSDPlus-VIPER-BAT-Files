:: NC VIPER - Durham County - RTP Bryan Ctr
:: RFSS 1 | Site 047 (0x2F) | Ctrl: 774.03125 MHz
:: All site freqs: 770.93125 771.13125 771.68125 772.38125 774.03125 774.28125
FMPA -rc -o20001 -f774.03125
