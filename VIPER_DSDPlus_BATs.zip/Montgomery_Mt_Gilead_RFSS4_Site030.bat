:: NC VIPER - Montgomery County - Mt Gilead
:: RFSS 4 | Site 030 (0x1E) | Ctrl: 853.250 MHz
:: All site freqs: 851.4125 851.9625 852.3625 853.250 853.8625 857.0125
FMPA -rc -o20001 -f853.250
