:: NC VIPER - Pamlico County - Bayboro
:: RFSS 3 | Site 005 (0x5) | Ctrl: 852.900 MHz
:: All site freqs: 851.3875 851.8875 852.450 852.900 853.4625 857.4875 857.7625
FMPA -rc -o20001 -f852.900
