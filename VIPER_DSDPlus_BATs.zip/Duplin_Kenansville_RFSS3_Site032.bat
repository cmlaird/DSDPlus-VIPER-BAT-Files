:: NC VIPER - Duplin County - Kenansville
:: RFSS 3 | Site 032 (0x20) | Ctrl: 772.75625 MHz
:: All site freqs: 770.84375 771.28125 771.90625 772.15625 772.40625 772.75625 773.95625
FMPA -rc -o20001 -f772.75625
