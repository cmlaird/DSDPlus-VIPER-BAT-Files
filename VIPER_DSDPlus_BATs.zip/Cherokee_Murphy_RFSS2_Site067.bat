:: NC VIPER - Cherokee County - Murphy
:: RFSS 2 | Site 067 (0x43) | Ctrl: 852.200 MHz
:: All site freqs: 851.0875 851.3375 851.900 852.200 853.8375
FMPA -rc -o20001 -f852.200
