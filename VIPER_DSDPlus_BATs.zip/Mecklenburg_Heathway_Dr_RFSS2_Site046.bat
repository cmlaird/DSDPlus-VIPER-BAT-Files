:: NC VIPER - Mecklenburg County - Heathway Dr
:: RFSS 2 | Site 046 (0x2E) | Ctrl: 854.8125 MHz
:: All site freqs: 851.175 851.550 852.1875 852.4375 852.6875 852.9875 853.175 853.6875 854.8125 859.4375
FMPA -rc -o20001 -f854.8125
