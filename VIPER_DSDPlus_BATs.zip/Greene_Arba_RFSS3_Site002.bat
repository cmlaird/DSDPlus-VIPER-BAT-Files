:: NC VIPER - Greene County - Arba
:: RFSS 3 | Site 002 (0x2) | Ctrl: 853.250 MHz
:: All site freqs: 851.9875 853.250 853.575 856.0375 857.0375 858.0375
FMPA -rc -o20001 -f853.250
