:: NC VIPER - Forsyth County - Clemmons
:: RFSS 4 | Site 009 (0x9) | Ctrl: 858.8375 MHz
:: All site freqs: 851.3375 852.025 852.3375 852.7125 853.250 853.775 857.5125 858.8375 859.7875
FMPA -rc -o20001 -f858.8375
