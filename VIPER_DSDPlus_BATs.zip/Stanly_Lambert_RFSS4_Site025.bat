:: NC VIPER - Stanly County - Lambert
:: RFSS 4 | Site 025 (0x19) | Ctrl: 858.6875 MHz
:: All site freqs: 856.0125 857.0625 857.5875 858.6875 859.0375
FMPA -rc -o20001 -f858.6875
