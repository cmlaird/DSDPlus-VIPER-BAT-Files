:: NC VIPER - Beaufort County - Bath
:: RFSS 3 | Site 004 (0x4) | Ctrl: 852.550 MHz
:: All site freqs: 851.1375 851.600 852.1625 852.550 853.8625 855.4625
FMPA -rc -o20001 -f852.550
