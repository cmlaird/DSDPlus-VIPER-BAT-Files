:: NC VIPER - Caswell County - Pelham
:: RFSS 1 | Site 040 (0x28) | Ctrl: 853.125 MHz
:: All site freqs: 851.3125 851.875 852.700 853.125 853.4375
FMPA -rc -o20001 -f853.125
