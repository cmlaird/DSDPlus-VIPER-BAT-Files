:: NC VIPER - Bertie County - Windsor
:: RFSS 3 | Site 071 (0x47) | Ctrl: 855.2375 MHz
:: All site freqs: 851.0375 851.5375 852.4125 852.875 853.875 855.2375 857.9875
FMPA -rc -o20001 -f855.2375
