:: NC VIPER - Columbus County - Nakina
:: RFSS 3 | Site 041 (0x29) | Ctrl: 771.58125 MHz
:: All site freqs: 769.80625 770.28125 770.75625 771.05625 771.30625 771.58125
FMPA -rc -o20001 -f771.58125
