:: NC VIPER - Dare County - Rodanthe
:: RFSS 3 | Site 054 (0x36) | Ctrl: 852.275 MHz
:: All site freqs: 851.0375 851.425 851.8375 852.275 853.2375
FMPA -rc -o20001 -f852.275
