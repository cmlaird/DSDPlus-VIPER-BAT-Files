:: NC VIPER - Pasquotank County - Elizabeth City
:: RFSS 3 | Site 019 (0x13) | Ctrl: 853.5625 MHz
:: All site freqs: 851.0625 851.475 851.9125 852.650 853.100 853.5625 854.3625 857.0625
FMPA -rc -o20001 -f853.5625
