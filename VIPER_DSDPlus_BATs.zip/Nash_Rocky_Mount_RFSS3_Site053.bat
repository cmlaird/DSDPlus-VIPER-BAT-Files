:: NC VIPER - Nash County - Rocky Mount
:: RFSS 3 | Site 053 (0x35) | Ctrl: 853.4375 MHz
:: All site freqs: 851.425 851.7875 852.175 852.400 852.675 852.8625 853.4375 854.6375
FMPA -rc -o20001 -f853.4375
