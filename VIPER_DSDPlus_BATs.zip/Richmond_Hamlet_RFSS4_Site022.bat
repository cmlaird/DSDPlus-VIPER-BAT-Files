:: NC VIPER - Richmond County - Hamlet
:: RFSS 4 | Site 022 (0x16) | Ctrl: 852.6625 MHz
:: All site freqs: 851.150 851.4375 852.275 852.6625 853.7375 854.0875
FMPA -rc -o20001 -f852.6625
