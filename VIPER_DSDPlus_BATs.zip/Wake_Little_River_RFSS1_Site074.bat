:: NC VIPER - Wake County - Little River
:: RFSS 1 | Site 074 (0x4A) | Ctrl: 858.4625 MHz
:: All site freqs: 851.3625 851.6875 853.7375 855.9625 856.4625 857.4625 858.4625 859.4625
FMPA -rc -o20001 -f858.4625
