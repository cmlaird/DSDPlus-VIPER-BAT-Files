:: NC VIPER - Buncombe County - Meadows Mtn
:: RFSS 2 | Site 059 (0x3B) | Ctrl: 855.2125 MHz
:: All site freqs: 851.1375 851.575 852.1625 852.7625 853.675 854.5125 855.2125 859.7375
FMPA -rc -o20001 -f855.2125
