:: NC VIPER - Northampton County - Odom DOC
:: RFSS 3 | Site 046 (0x2E) | Ctrl: 774.48125 MHz
:: All site freqs: 770.53125 771.61875 772.88125 774.18125 774.48125
FMPA -rc -o20001 -f774.48125
