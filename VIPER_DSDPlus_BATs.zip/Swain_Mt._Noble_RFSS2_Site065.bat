:: NC VIPER - Swain County - Mt. Noble
:: RFSS 2 | Site 065 (0x41) | Ctrl: 853.2875 MHz
:: All site freqs: 851.450 852.1375 852.725 853.2875 853.9375
FMPA -rc -o20001 -f853.2875
