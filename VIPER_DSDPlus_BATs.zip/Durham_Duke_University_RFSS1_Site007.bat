:: NC VIPER - Durham County - Duke University
:: RFSS 1 | Site 007 (0x7) | Ctrl: 857.8625 MHz
:: All site freqs: 852.450 853.5125 854.8375 855.2875 855.5875 856.8375 857.8625 858.8375
FMPA -rc -o20001 -f857.8625
