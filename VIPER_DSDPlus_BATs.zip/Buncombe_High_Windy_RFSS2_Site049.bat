:: NC VIPER - Buncombe County - High Windy
:: RFSS 2 | Site 049 (0x31) | Ctrl: 853.7625 MHz
:: All site freqs: 851.675 852.1125 853.7625 854.6125 858.5125 858.7875
FMPA -rc -o20001 -f853.7625
