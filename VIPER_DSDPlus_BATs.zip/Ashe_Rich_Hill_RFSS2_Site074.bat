:: NC VIPER - Ashe County - Rich Hill
:: RFSS 2 | Site 074 (0x4A) | Ctrl: 773.41875 MHz
:: All site freqs: 771.30625 771.88125 772.20625 773.41875 774.20625
FMPA -rc -o20001 -f773.41875
