:: NC VIPER - Durham County - Camden Ave
:: RFSS 1 | Site 009 (0x9) | Ctrl: 855.1125 MHz
:: All site freqs: 851.600 852.075 852.4125 852.9125 853.5875 853.875 855.1125 858.8125
FMPA -rc -o20001 -f855.1125
