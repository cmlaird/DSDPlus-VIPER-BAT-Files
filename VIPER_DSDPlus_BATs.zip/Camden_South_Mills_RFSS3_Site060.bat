:: NC VIPER - Camden County - South Mills
:: RFSS 3 | Site 060 (0x3C) | Ctrl: 852.6375 MHz
:: All site freqs: 851.075 851.325 851.800 852.6375 853.675 856.4375 856.9375 858.0625
FMPA -rc -o20001 -f852.6375
