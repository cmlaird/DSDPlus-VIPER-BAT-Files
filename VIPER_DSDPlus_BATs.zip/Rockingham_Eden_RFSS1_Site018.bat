:: NC VIPER - Rockingham County - Eden
:: RFSS 1 | Site 018 (0x12) | Ctrl: 853.925 MHz
:: All site freqs: 851.0625 851.575 852.0625 852.200 852.6625 853.375 853.925 860.7375
FMPA -rc -o20001 -f853.925
