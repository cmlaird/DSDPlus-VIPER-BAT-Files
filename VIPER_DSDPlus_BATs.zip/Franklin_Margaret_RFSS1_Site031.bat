:: NC VIPER - Franklin County - Margaret
:: RFSS 1 | Site 031 (0x1F) | Ctrl: 853.8375 MHz
:: All site freqs: 851.3125 851.8875 852.850 853.075 853.300 853.8375 859.0625
FMPA -rc -o20001 -f853.8375
