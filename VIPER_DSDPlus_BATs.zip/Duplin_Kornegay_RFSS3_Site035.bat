:: NC VIPER - Duplin County - Kornegay
:: RFSS 3 | Site 035 (0x23) | Ctrl: 852.950 MHz
:: All site freqs: 851.075 852.250 852.725 852.950 853.6375
FMPA -rc -o20001 -f852.950
