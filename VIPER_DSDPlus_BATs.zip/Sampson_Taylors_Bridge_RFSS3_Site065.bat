:: NC VIPER - Sampson County - Taylors Bridge
:: RFSS 3 | Site 065 (0x41) | Ctrl: 853.075 MHz
:: All site freqs: 851.175 851.4875 851.900 852.550 852.850 853.075 853.325
FMPA -rc -o20001 -f853.075
