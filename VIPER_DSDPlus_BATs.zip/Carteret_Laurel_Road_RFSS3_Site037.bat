:: NC VIPER - Carteret County - Laurel Road
:: RFSS 3 | Site 037 (0x25) | Ctrl: 852.3625 MHz
:: All site freqs: 851.100 851.425 851.9875 852.3625 853.750
FMPA -rc -o20001 -f852.3625
