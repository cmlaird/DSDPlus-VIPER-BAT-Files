:: NC VIPER - Hyde County - Ocracoke
:: RFSS 3 | Site 045 (0x2D) | Ctrl: 852.9625 MHz
:: All site freqs: 851.4625 852.0625 852.650 852.9625 853.5125
FMPA -rc -o20001 -f852.9625
