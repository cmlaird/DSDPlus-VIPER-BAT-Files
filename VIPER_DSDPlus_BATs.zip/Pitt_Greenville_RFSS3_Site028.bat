:: NC VIPER - Pitt County - Greenville
:: RFSS 3 | Site 028 (0x1C) | Ctrl: 853.375 MHz
:: All site freqs: 851.3625 851.6125 852.1375 852.4875 852.7375 852.9875 853.375 853.900
FMPA -rc -o20001 -f853.375
