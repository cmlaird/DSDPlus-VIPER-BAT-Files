:: NC VIPER - Mitchell County - Locust Knob
:: RFSS 2 | Site 057 (0x39) | Ctrl: 852.7875 MHz
:: All site freqs: 851.300 851.6625 852.175 852.7875 853.750
FMPA -rc -o20001 -f852.7875
