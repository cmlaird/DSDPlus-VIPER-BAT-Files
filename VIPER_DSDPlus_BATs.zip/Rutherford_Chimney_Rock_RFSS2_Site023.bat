:: NC VIPER - Rutherford County - Chimney Rock
:: RFSS 2 | Site 023 (0x17) | Ctrl: 770.75625 MHz
:: All site freqs: 769.50625 769.84375 770.51875 770.75625 771.58125 772.58125 773.65625
FMPA -rc -o20001 -f770.75625
