:: NC VIPER - Avery County - Hawshaw #241
:: RFSS 2 | Site 068 (0x44) | Ctrl: 773.93125 MHz
:: All site freqs: 771.04375 771.54375 772.66875 773.18125 773.93125 774.21875
FMPA -rc -o20001 -f773.93125
