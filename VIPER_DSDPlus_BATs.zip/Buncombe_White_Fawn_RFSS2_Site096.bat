:: NC VIPER - Buncombe County - White Fawn
:: RFSS 2 | Site 096 (0x60) | Ctrl: 852.6875 MHz
:: All site freqs: 851.5625 851.7125 851.9375 852.6875 852.9625 853.825 854.6375
FMPA -rc -o20001 -f852.6875
