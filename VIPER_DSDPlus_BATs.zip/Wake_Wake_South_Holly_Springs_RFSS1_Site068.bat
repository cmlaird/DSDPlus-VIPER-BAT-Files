:: NC VIPER - Wake County - Wake South Holly Springs
:: RFSS 1 | Site 068 (0x44) | Ctrl: 852.6125 MHz
:: All site freqs: 851.375 851.675 851.875 852.125 852.375 852.6125 852.8125 853.0625 853.375 857.0125
FMPA -rc -o20001 -f852.6125
