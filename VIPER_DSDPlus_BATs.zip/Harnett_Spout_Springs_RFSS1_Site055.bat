:: NC VIPER - Harnett County - Spout Springs
:: RFSS 1 | Site 055 (0x37) | Ctrl: 853.975 MHz
:: All site freqs: 851.5875 851.900 852.3625 853.125 853.500 853.750 853.975 854.2375
FMPA -rc -o20001 -f853.975
