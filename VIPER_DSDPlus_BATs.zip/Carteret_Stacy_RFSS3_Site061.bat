:: NC VIPER - Carteret County - Stacy
:: RFSS 3 | Site 061 (0x3D) | Ctrl: 853.0875 MHz
:: All site freqs: 851.5875 852.0875 852.5875 853.0875 853.5875
FMPA -rc -o20001 -f853.0875
