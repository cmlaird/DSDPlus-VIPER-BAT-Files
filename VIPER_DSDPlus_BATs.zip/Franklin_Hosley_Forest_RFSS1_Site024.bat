:: NC VIPER - Franklin County - Hosley Forest
:: RFSS 1 | Site 024 (0x18) | Ctrl: 856.0375 MHz
:: All site freqs: 851.1625 851.550 851.8625 852.3625 853.7125 856.0375 858.0375
FMPA -rc -o20001 -f856.0375
