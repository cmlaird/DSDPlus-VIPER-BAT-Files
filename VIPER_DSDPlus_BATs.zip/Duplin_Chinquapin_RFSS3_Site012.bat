:: NC VIPER - Duplin County - Chinquapin
:: RFSS 3 | Site 012 (0xC) | Ctrl: 853.350 MHz
:: All site freqs: 851.600 852.225 852.9125 853.350 853.7625
FMPA -rc -o20001 -f853.350
