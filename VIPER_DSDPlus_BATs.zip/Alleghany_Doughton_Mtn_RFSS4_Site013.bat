:: NC VIPER - Alleghany County - Doughton Mtn
:: RFSS 4 | Site 013 (0xD) | Ctrl: 853.725 MHz
:: All site freqs: 851.3625 852.600 853.175 853.725 854.9875
FMPA -rc -o20001 -f853.725
