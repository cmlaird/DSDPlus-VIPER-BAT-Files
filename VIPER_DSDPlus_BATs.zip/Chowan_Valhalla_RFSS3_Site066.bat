:: NC VIPER - Chowan County - Valhalla
:: RFSS 3 | Site 066 (0x42) | Ctrl: 852.3625 MHz
:: All site freqs: 851.100 851.425 851.9875 852.3625 853.750 858.0125
FMPA -rc -o20001 -f852.3625
