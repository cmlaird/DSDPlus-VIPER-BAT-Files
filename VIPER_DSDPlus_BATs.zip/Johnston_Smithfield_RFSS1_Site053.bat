:: NC VIPER - Johnston County - Smithfield
:: RFSS 1 | Site 053 (0x35) | Ctrl: 856.0125 MHz
:: All site freqs: 851.350 852.5875 853.175 853.675 853.900 854.8625 856.0125 859.6875
FMPA -rc -o20001 -f856.0125
