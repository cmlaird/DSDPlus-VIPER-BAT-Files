:: NC VIPER - Carteret County - Kuhns PE
:: RFSS 3 | Site 036 (0x24) | Ctrl: 853.850 MHz
:: All site freqs: 853.850 856.2125 857.2125 858.2125 859.2125
FMPA -rc -o20001 -f853.850
