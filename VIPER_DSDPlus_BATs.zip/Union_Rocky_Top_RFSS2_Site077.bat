:: NC VIPER - Union County - Rocky Top
:: RFSS 2 | Site 077 (0x4D) | Ctrl: 773.14375 MHz
:: All site freqs: 772.11875 772.49375 772.96875 773.14375 773.71875
FMPA -rc -o20001 -f773.14375
