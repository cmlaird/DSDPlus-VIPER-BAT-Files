:: NC VIPER - Macon County - Scaly Mtn
:: RFSS 2 | Site 079 (0x4F) | Ctrl: 853.275 MHz
:: All site freqs: 851.5375 852.1375 852.9125 853.275 853.500
FMPA -rc -o20001 -f853.275
