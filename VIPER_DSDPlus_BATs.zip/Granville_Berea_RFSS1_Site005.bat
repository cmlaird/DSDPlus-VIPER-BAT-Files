:: NC VIPER - Granville County - Berea
:: RFSS 1 | Site 005 (0x5) | Ctrl: 853.1375 MHz
:: All site freqs: 851.2125 851.6375 852.250 852.475 852.750 853.1375 853.750
FMPA -rc -o20001 -f853.1375
