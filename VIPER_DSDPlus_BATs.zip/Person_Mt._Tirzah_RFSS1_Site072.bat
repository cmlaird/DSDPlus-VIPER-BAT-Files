:: NC VIPER - Person County - Mt. Tirzah
:: RFSS 1 | Site 072 (0x48) | Ctrl: 769.26875 MHz
:: All site freqs: 769.26875 769.51875 771.24375 771.79375 772.24375 772.66875
FMPA -rc -o20001 -f769.26875
