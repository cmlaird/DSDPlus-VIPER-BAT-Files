:: NC VIPER - Macon County - Cowee Bald
:: RFSS 2 | Site 029 (0x1D) | Ctrl: 852.300 MHz
:: All site freqs: 851.175 851.600 851.950 852.300 852.975 853.725
FMPA -rc -o20001 -f852.300
