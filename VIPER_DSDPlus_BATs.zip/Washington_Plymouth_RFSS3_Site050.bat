:: NC VIPER - Washington County - Plymouth
:: RFSS 3 | Site 050 (0x32) | Ctrl: 856.2125 MHz
:: All site freqs: 851.050 851.400 851.925 852.3875 853.8375 856.2125 857.2125
FMPA -rc -o20001 -f856.2125
