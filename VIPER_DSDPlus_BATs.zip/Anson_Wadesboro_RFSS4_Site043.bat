:: NC VIPER - Anson County - Wadesboro
:: RFSS 4 | Site 043 (0x2B) | Ctrl: 852.6375 MHz
:: All site freqs: 851.300 851.750 852.125 852.6375 853.750
FMPA -rc -o20001 -f852.6375
