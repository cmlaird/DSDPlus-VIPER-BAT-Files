:: NC VIPER - Union County - Waxhaw AAA
:: RFSS 4 | Site 044 (0x2C) | Ctrl: 857.6125 MHz
:: All site freqs: 851.400 852.050 852.7625 857.6125 858.6125
FMPA -rc -o20001 -f857.6125
