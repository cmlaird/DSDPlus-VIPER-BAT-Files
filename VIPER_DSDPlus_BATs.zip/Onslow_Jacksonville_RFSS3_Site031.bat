:: NC VIPER - Onslow County - Jacksonville
:: RFSS 3 | Site 031 (0x1F) | Ctrl: 852.975 MHz
:: All site freqs: 852.2125 852.475 852.7125 852.975 853.975
FMPA -rc -o20001 -f852.975
