:: NC VIPER - Beaufort County - Chocowinity
:: RFSS 3 | Site 013 (0xD) | Ctrl: 856.7125 MHz
:: All site freqs: 851.1625 851.875 852.275 852.6875 853.775 856.7125 858.7125
FMPA -rc -o20001 -f856.7125
