:: NC VIPER - Iredell County - Fox Mtn
:: RFSS 4 | Site 019 (0x13) | Ctrl: 853.200 MHz
:: All site freqs: 851.0875 851.6375 852.875 853.200 853.525 858.5125 859.6375
FMPA -rc -o20001 -f853.200
