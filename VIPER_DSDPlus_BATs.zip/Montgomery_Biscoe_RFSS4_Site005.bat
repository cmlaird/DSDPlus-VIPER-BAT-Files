:: NC VIPER - Montgomery County - Biscoe
:: RFSS 4 | Site 005 (0x5) | Ctrl: 852.7125 MHz
:: All site freqs: 851.175 851.7375 851.9375 852.375 852.7125 853.725 859.1875
FMPA -rc -o20001 -f852.7125
