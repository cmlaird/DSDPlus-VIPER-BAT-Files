:: NC VIPER - Pender County - Penderlea
:: RFSS 3 | Site 049 (0x31) | Ctrl: 853.150 MHz
:: All site freqs: 851.925 852.1625 852.450 853.150 853.450 853.925 857.4375 858.4375
FMPA -rc -o20001 -f853.150
