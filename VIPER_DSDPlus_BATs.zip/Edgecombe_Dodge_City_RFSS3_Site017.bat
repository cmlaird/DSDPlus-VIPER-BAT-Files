:: NC VIPER - Edgecombe County - Dodge City
:: RFSS 3 | Site 017 (0x11) | Ctrl: 852.1125 MHz
:: All site freqs: 851.1125 851.475 852.1125 852.6625 853.975 855.7375 857.0625
FMPA -rc -o20001 -f852.1125
