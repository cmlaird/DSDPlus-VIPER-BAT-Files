:: NC VIPER - Johnston County - Archers Lodge
:: RFSS 1 | Site 002 (0x2) | Ctrl: 855.0375 MHz
:: All site freqs: 851.400 852.425 853.475 853.8625 855.0375 855.7625
FMPA -rc -o20001 -f855.0375
