:: NC VIPER - Lenoir County - Kinston
:: RFSS 3 | Site 033 (0x21) | Ctrl: 853.4125 MHz
:: All site freqs: 851.6875 852.4125 852.925 853.4125 853.7375
FMPA -rc -o20001 -f853.4125
