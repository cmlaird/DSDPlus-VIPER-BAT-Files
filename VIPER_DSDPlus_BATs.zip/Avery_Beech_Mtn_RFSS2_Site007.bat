:: NC VIPER - Avery County - Beech Mtn
:: RFSS 2 | Site 007 (0x7) | Ctrl: 852.9125 MHz
:: All site freqs: 851.2625 851.8125 852.650 852.9125 853.875
FMPA -rc -o20001 -f852.9125
