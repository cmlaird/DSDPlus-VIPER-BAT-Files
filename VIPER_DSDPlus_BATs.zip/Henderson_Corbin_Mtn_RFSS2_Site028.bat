:: NC VIPER - Henderson County - Corbin Mtn
:: RFSS 2 | Site 028 (0x1C) | Ctrl: 851.5875 MHz
:: All site freqs: 851.275 851.5875 851.850 852.4875 853.9125
FMPA -rc -o20001 -f851.5875
