:: NC VIPER - Haywood County - Hazel Top
:: RFSS 2 | Site 045 (0x2D) | Ctrl: 774.28125 MHz
:: All site freqs: 773.08125 773.53125 773.78125 774.28125 774.55625
FMPA -rc -o20001 -f774.28125
