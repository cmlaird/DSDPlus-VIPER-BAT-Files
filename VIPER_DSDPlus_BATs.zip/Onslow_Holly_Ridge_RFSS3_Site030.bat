:: NC VIPER - Onslow County - Holly Ridge
:: RFSS 3 | Site 030 (0x1E) | Ctrl: 856.4375 MHz
:: All site freqs: 851.675 852.1875 852.6875 853.175 853.675 854.9875 856.1625 856.4375 856.7125
FMPA -rc -o20001 -f856.4375
