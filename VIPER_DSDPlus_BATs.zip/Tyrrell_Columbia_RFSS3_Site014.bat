:: NC VIPER - Tyrrell County - Columbia
:: RFSS 3 | Site 014 (0xE) | Ctrl: 852.4375 MHz
:: All site freqs: 851.1125 851.4875 851.9625 852.4375 853.6125
FMPA -rc -o20001 -f852.4375
