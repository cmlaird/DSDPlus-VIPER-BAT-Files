:: NC VIPER - Madison County - Big Knob
:: RFSS 2 | Site 010 (0xA) | Ctrl: 852.6125 MHz
:: All site freqs: 851.050 851.400 851.850 852.6125 853.2375
FMPA -rc -o20001 -f852.6125
