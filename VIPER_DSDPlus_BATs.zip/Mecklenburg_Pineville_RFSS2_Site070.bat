:: NC VIPER - Mecklenburg County - Pineville
:: RFSS 2 | Site 070 (0x46) | Ctrl: 852.9625 MHz
:: All site freqs: 851.075 851.275 851.8875 852.225 852.9625 853.2125 853.825
FMPA -rc -o20001 -f852.9625
