:: NC VIPER - Franklin County - Louisburg
:: RFSS 1 | Site 029 (0x1D) | Ctrl: 853.6375 MHz
:: All site freqs: 852.1375 852.625 852.875 853.1125 853.3625 853.6375 853.9375
FMPA -rc -o20001 -f853.6375
