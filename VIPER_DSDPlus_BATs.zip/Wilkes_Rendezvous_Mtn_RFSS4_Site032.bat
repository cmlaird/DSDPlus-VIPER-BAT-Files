:: NC VIPER - Wilkes County - Rendezvous Mtn
:: RFSS 4 | Site 032 (0x20) | Ctrl: 857.1875 MHz
:: All site freqs: 853.500 854.4625 854.6625 856.0875 857.1875 858.0875
FMPA -rc -o20001 -f857.1875
