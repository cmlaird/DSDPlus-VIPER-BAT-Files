:: NC VIPER - Duplin County - Wallace
:: RFSS 3 | Site 067 (0x43) | Ctrl: 853.2125 MHz
:: All site freqs: 851.800 852.3125 852.675 853.2125 853.6875 857.7125 859.4375
FMPA -rc -o20001 -f853.2125
