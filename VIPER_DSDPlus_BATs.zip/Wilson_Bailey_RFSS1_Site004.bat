:: NC VIPER - Wilson County - Bailey
:: RFSS 1 | Site 004 (0x4) | Ctrl: 856.5125 MHz
:: All site freqs: 851.100 851.325 851.825 852.350 855.6125 856.1875 856.5125 857.1875
FMPA -rc -o20001 -f856.5125
